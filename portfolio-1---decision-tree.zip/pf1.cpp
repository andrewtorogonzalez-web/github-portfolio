//=============================================================================
// Name: Andrew Toro Gonzalez
// E-mail: torogonz@usc.edu
// Description: provide a 1-2 sentence description of your program
// My program is a personality quiz that collects a player's score and selects a personality for the user based on their selected answer choices.
// ------------------------ Test case Inputs ----------------------------------
//  Show what literal input we should be typed to test your program. Then,
//  show us what will be output for that particular input (what should we expect
//  see when we type that input?).
//  If your program has some notion of randomness show a sample runs so we can
//  try to verify it if we ran it a few times.
//  Test 1 input: ' Your Name, 'A 
//                              A 
//                              A 
//                              A 
//                              A 
//                              1 
//                              5.0'
//   <what literal input should we type in to test your program>

//  Test 1 output: ' 
//                   Answer some questions and learn about your personality, Your Name!
//                   Be sure to input: A B C or 1 or 2 for the bonus question
//                   Question 1: What is your favorite vacation spot?
//                   A. Mountains, B. Camping, C. Beaches
//                   Question 2: What do you like to do in your free time?
//                   A. Go to the gym, B. Read a book, C. Scroll on social media
//                   Question 3: How would your friends describe you?"
//                   A. Energetic, B. Caring, C. Reserved
//                   Question 4: Which drink out of the three do you like the most?
//                   A. Coffee, B. Hot Chocolate, C. Tea
//                   Question 5: What is your favorite app?
//                   A. Tiktok, B. Instagram, C. YouTube
//                   Bonus Question: Would you sacrifice your friend to save the world?
//                   1. Yes or 2. No
//                   Your Name, you have a confident personality: Leader
//                   From a score of 1.0-5.0, how would you rate the personality quiz?
//                   Thank you for a perfect score! :)
//   <what output should we expect for that input>
// 
//  Test 2 input: 'Your Name
//                 B
//                 B 
//                 B 
//                 B 
//                 B 
//                 2 
//                 1.0'
//   <what input should we type in to test your program>
//  Test 2 output:   '
//                   Answer some questions and learn about your personality, Your Name!
//                   Be sure to input: A B C or 1 or 2 for the bonus question
//                   Question 1: What is your favorite vacation spot?
//                   A. Mountains, B. Camping, C. Beaches
//                   Question 2: What do you like to do in your free time?
//                   A. Go to the gym, B. Read a book, C. Scroll on social media
//                   Question 3: How would your friends describe you?"
//                   A. Energetic, B. Caring, C. Reserved
//                   Question 4: Which drink out of the three do you like the most?
//                   A. Coffee, B. Hot Chocolate, C. Tea
//                   Question 5: What is your favorite app?
//                   A. Tiktok, B. Instagram, C. YouTube
//                   Bonus Question: Which season do you prefer?
//                   1. Summer or 2. Winter
//                   Your Name, you have an easy-going personality: Detail-Oriented
//                   From a score of 1.0-5.0, how would you rate the personality quiz?
//                   Sorry that the quiz disappointed you.'
//  <what output should we expect for that input>
//  Test 3 Input:  'Your Name
//                 C
//                 C 
//                 C
//                 C 
//                 C 
//                 1 
//                 3.0'
//  Test 3 Output:   
//                  ' Answer some questions and learn about your personality, Your Name!
//                   Be sure to input: A B C or 1 or 2 for the bonus question
//                   Question 1: What is your favorite vacation spot?
//                   A. Mountains, B. Camping, C. Beaches
//                   Question 2: What do you like to do in your free time?
//                   A. Go to the gym, B. Read a book, C. Scroll on social media
//                   Question 3: How would your friends describe you?"
//                   A. Energetic, B. Caring, C. Reserved
//                   Question 4: Which drink out of the three do you like the most?
//                   A. Coffee, B. Hot Chocolate, C. Tea
//                   Question 5: What is your favorite app?
//                   A. Tiktok, B. Instagram, C. YouTube
//                   Bonus Question: Do you prefer spicy snacks or sweet snacks
//                   1. Spicy snacks or 2. Sweet snacks;
//                   Your Name, you have an independent personality: Free Spirit
//                   From a score of 1.0-5.0, how would you rate the personality quiz?
//                   Glad you liked the quiz! '
//  Test 4 Input:  'Your Name
//                 A
//                 B 
//                 B
//                 C 
//                 C 
//                 1 
//                 4.2'
//  Test 4 Output:   
//                   'Answer some questions and learn about your personality, Your Name!
//                   Be sure to input: A B C or 1 or 2 for the bonus question
//                   Question 1: What is your favorite vacation spot?
//                   A. Mountains, B. Camping, C. Beaches
//                   Question 2: What do you like to do in your free time?
//                   A. Go to the gym, B. Read a book, C. Scroll on social media
//                   Question 3: How would your friends describe you?"
//                   A. Energetic, B. Caring, C. Reserved
//                   Question 4: Which drink out of the three do you like the most?
//                   A. Coffee, B. Hot Chocolate, C. Tea
//                   Question 5: What is your favorite app?
//                   A. Tiktok, B. Instagram, C. YouTube
//                   Bonus Question: Which season do you prefer?
//                   1. Summer or 2. Winter
//                   Your Name, you have an easy-going personality: Optimist
//                   From a score of 1.0-5.0, how would you rate the personality quiz?
//                   Glad you liked the quiz!'
//  If your program has some notion of randomness, tell use what 
//  N/A
//
//=============================================================================

// ------------ Add #includes and other statements here ----------
  #include <iostream>
  #include <string>
  using namespace std;

// ------------ Add your main() function below ----------
int main () {
  // Declaring variables for player input, input for the bonus question, a string for the playerName, 
  //the player's score which impacts the results,  and the player's rating regarding the personality quiz
  
  char playerInput;
  int bonusQuestionInput;
  string playerName; //Make it more personalized
  int playerScore = 0;
  double playerRating;
  
  //Intro
  cout << " " << endl; // Done to give a line of space for each question
  cout << "Hi! What's your name?" << endl;
  cin >> playerName;
  cout << " " << endl;
  cout << "Answer some questions and learn about your personality," << " " << playerName + '!' << endl;
  cout << "Be sure to input:" << " " << "A" << " " << "B" << " " << "C," << " " << "or" << " "<< "1" << " "  << "or 2 for the bonus question" <<endl;
  cout << " " << endl; 

  //Question 1 and its impacts on playerScore
  cout << "Question 1:" << " " << "What is your favorite vacation spot?" << endl;
  cout << "A. Mountains, B. Camping, C. Beaches" << endl;
  cin >> playerInput;

  if(playerInput == 'A') {
    playerScore = playerScore + 3;
  } else if(playerInput == 'B') {
    playerScore = playerScore + 2;
  } else if(playerInput == 'C') {
    playerScore = playerScore + 1;
  } 

  // Question 2 and its impacts on playerScore
  cout << " " << endl; 
  cout << "Question 2:" << " " << "What do you like to do in your free time?" << endl;
  cout << "A. Go to the gym, B. Read a book, C. Scroll on social media" << endl;
  cin >> playerInput;

  if(playerInput == 'A') {
    playerScore = playerScore + 3;
  } else if(playerInput == 'B') {
    playerScore = playerScore + 2;
  } else if(playerInput == 'C') {
    playerScore = playerScore + 1;
  } 

  // Question 3 and its impacts on PlayerScore
  cout << " " << endl;
  cout << "Question 3:" << " " << "How would your friends describe you?" << endl; 
  cout << "A. Energetic, B. Caring, C. Reserved" << endl;
  cin >> playerInput;

  if(playerInput == 'A') {
    playerScore = playerScore + 3;
  } else if(playerInput == 'B') {
    playerScore = playerScore + 2;
  } else if(playerInput == 'C') {
    playerScore = playerScore + 1;
  }
  //Question 4 and its impacts on PlayerScore
  cout << " " << endl;
  cout << "Question 4:" << " " << "Which drink out of the three do you like the most?" << endl;
  cout << "A. Coffee, B. Hot Chocolate, C. Tea" << endl;
  cin >> playerInput;

  if(playerInput == 'A') {
    playerScore = playerScore + 3;
  } else if(playerInput == 'B') {
    playerScore = playerScore + 2;
  } else if(playerInput == 'C') {
    playerScore = playerScore + 1;
  }
  //Question 5 and its impacts on PlayerScore
  cout << " " << endl;
  cout << "Question 5:" << " " << "What is your favorite app?" << endl;
  cout << "A. Tiktok, B. Instagram, C. YouTube" << endl;
  cin >> playerInput;

  if(playerInput == 'A') {
    playerScore = playerScore + 3;
  } else if(playerInput == 'B') {
    playerScore = playerScore + 2;
  } else if(playerInput == 'C') {
    playerScore = playerScore + 1;
  }
  //Score Results + Sub personality
  cout << " " << endl;
  if(playerScore >= 12) {
    cout << "Bonus Question:" << " " << "Would you sacrifice your friend to save the world?" << endl;
    cout << "1. Yes or 2. No" << endl;
    cin >> bonusQuestionInput;
    if (bonusQuestionInput == 1) {
      cout << " " << endl;
      cout << playerName + ',' << " you have a confident personality: Leader" << endl;
    } else if(playerInput == 2) {
      cout << " " << endl;
      cout << playerName + ',' << " you have a confident personality: Social Butterfly" << endl;
    }
  } else if (playerScore >= 8) {
    cout << "Bonus Question:" << " " << "Which season do you prefer?" << endl;
    cout << "1. Summer or 2. Winter" << endl;
    cin >> bonusQuestionInput;
    if (bonusQuestionInput == 1) {
      cout << " " << endl;
      cout << playerName + ',' << " you have an easy-going personality: Optimist" << endl;
    } else if(bonusQuestionInput == 2) {
      cout << " " << endl;
      cout << playerName + ',' << " you have an easy-going personality: Detail-Oriented" << endl;
    }
  } else if(playerScore < 8) {
    cout << "Bonus Question:" << " " << "Do you prefer spicy snacks or sweet snacks" << endl;
    cout << "1. Spicy snacks or 2. Sweet snacks" << endl;
    cin >> bonusQuestionInput;
    if (bonusQuestionInput == 1) {
      cout << " " << endl;
      cout << playerName + ',' << " you have an independent personality: Free Spirit" << endl;
    } else if(bonusQuestionInput == 2) {
      cout << " " << endl;
      cout << playerName + ',' << " you have an independent personality: Day-Dreamer" << endl;
    }
  }
  // Collects The Player's Rating on the Personality Question
  cout << " " << endl;
  cout << "From a score of 1.0-5.0, how would you rate the personality quiz?" << endl;
  cin >> playerRating;
  cout << " " << endl; 

  if (playerRating < 3.0) {
    cout << "Sorry that the quiz disappointed you." << endl;
  } else if(playerRating >= 3.0 && playerRating < 5.0) {
    cout << "Glad you liked the quiz!" << endl;
  } else if (playerRating == 5.0) {
    cout << "Thank you for a perfect score! :)" << endl;
  }
}

