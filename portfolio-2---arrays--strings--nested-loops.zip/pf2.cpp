//=============================================================================
// Name: Andrew Toro Gonzalez
// E-mail: torogonz@usc.edu
// Description: provide a 1-2 sentence description of your program
//
// ------------------------ Test case Inputs ----------------------------------
//  Test 1 input: 
//  <what input should we type in to test your program>
//  A 1 1, A 2 1, A 3 2, R 3 1, E
//  Test 1 output: 
//   <what output should we expect for that input>
//   Final Total: $10.00
//   Thank you for shopping at El Toro's Candy Shop. Have a nice day!
// 
//  Test 2 input:
//   <what input should we type in to test your program>
//    A 3 3, R 3 3, E
//  Test 2 output:
//   <what output should we expect for that input>
//   Final Total: $0.00
//   Thank you for shopping at El Toro's Candy Shop. Have a nice day!
//
//=============================================================================

// ------------ Add #includes and other statements here ----------
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

// ------------ Add your main() function below ----------
int main() {
  //Variables for Online Store
  int numOfProducts = 3;
  string productNames[3] = {"Mazapan", "Chocolate", "Tamarind Candies"};
  double productPrices[3] = {3.00, 2.50, 4.50};

  // Used to track quantity of items in their carts
  int quantityInCart[3] = {0, 0, 0};

  char playerInput;
  bool shopping = true; //Condition that runs loop that checks if the user is shopping

  cout << " " << endl;
  cout << "Welcome to El Toro's Candy Shop! Type in A, R, E to add, remove, or checkout." << endl;
  cout << " " << endl;

  //If shopping is true, the while loop will keep running
  while(shopping){

    //Loop for the display menu

    cout << " -- Available Products -- " << endl;
    cout << "ID | Product  | Price" << endl;

    for(int i = 0; i < numOfProducts; i++) {
      cout << fixed << setprecision(2);
      cout << i + 1 << "  | " << productNames[i] << "  | $ " << productPrices[i] << endl;
    }
  
    // Menu Options and Inputs 
    cout << " " << endl;
    cout << "Menu: Add Item: A, Remove Item: R, Check out/Exit Menu: E" << endl;

    cin >> playerInput;
    
    //itemID directs user to which product they want to buy & quantityOfItem is the amount they want to purchase
    int itemID;
    int quantityOfItem;

    if(playerInput == 'A' || playerInput == 'R') {
      cout << " " << endl;
      cout << "Enter Item ID (1-" << numOfProducts << "): ";
      cin >> itemID;
      
      //Checks if itemID actually exists 
      if (itemID < 1 || itemID > numOfProducts) {
        cout << " " << endl;
        cout << "Invalid Item ID. Please try again" << endl;
        cout << " " << endl;
        continue;
      }
     
      cout << " " << endl;
      cout << "Enter Quanity of Item: ";
      cin >> quantityOfItem;

      int index = itemID - 1; //Done to set index to 0 for the array

      if(playerInput == 'A') {
        //Add items to your cart
        quantityInCart[index] += quantityOfItem;
        cout << " " << endl;
        cout << quantityOfItem << " " << productNames[index] << "(s) added to cart." << endl;
        cout << " " << endl;
      } else if(playerInput == 'R') {
        //Remove Items from your cart
        //If statement checks that the items in your cart can't be more than zero
        if(quantityInCart[index] >= quantityOfItem) {
          quantityInCart[index] -= quantityOfItem;
          cout << " " << endl;
          cout << quantityOfItem << " " << productNames[index] << "(s) removed from cart." << endl;
          cout << " " << endl;
        } else {
          cout << " " << endl;
          cout << "You can't remove that many items from your cart. Only " << quantityInCart[index] << " is in your cart." << endl;
          cout << " " << endl;
    }}
  } else if(playerInput == 'E') {
        //Exit the loop 
        shopping = false;
      } else {
        //Done for any invalid inputs 
        cout << " " << endl;
        cout << "Invalid Input. Please type in A, R, or E.";
        cout << " " << endl;
      }
  }
  //Checkout and Calculation of Costs

    double finalTotal = 0.00;
    cout << " " << endl;
    cout << " -- Checkout Summary -- " << endl;

    //Loop to calculate total cost 
    for(int i = 0; i < numOfProducts; i++){
      if(quantityInCart[i] > 0) {
        double lineTotal = quantityInCart[i] * productPrices[i];
        finalTotal += lineTotal;
        cout << quantityInCart[i] << " x " << productNames[i] << " @ $" 
        << productPrices[i] << " = $" << lineTotal << endl;
        cout << " " << endl;
      }
    }

    //Final Total and Output
    cout << fixed << setprecision(2);
    cout << " --------- " << endl;
    cout << "Final Total: $" << finalTotal << endl;
    cout << " " << endl;
    cout << "Thank you for shopping at El Toro's Candy Shop. Have a nice day!" << endl;
    cout << " " << endl;

  return 0;
}

